import threading
import socket

def print_message(s):
    while True:
        data = s.recv(1024)

        if data:
            print("\nrecived: ", data,)

def send_message(s):
    while True:
        message = input("invia un messaggio: ")
        message = bytes(message, 'utf-8')

        s.sendto(message,('192.168.1.71', 5055,))

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect(('192.168.1.71', 5055))
    t1 = threading.Thread(target=send_message, args=(s,))
    t2 = threading.Thread(target=print_message, args=(s,))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

                                                                                                         